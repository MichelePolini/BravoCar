<template>
  <div class="wrapper">
    <parallax class="section page-header header-filter" :style="headerStyle">
      <div class="container">
        <div class="md-layout">
          <div
            class="md-layout-item md-size-50 md-small-size-70 md-xsmall-size-100"
          >
            <h1 class="title">Your Journey Starts With Us.</h1>
            <h4>
              Come and dicorver us !
            </h4>
            <br />
           <!-- <md-button
              href="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
              class="md-success md-lg"
              target="_blank"
              ><i class="fas fa-play"></i> Watch video</md-button
            > -->
          </div>
        </div>
      </div>
    </parallax>
    <div class="main main-raised">
      <div class="section">
        <div class="container">
          <div class="md-layout">
            <div
              class="md-layout-item md-size-66 md-xsmall-size-100 mx-auto text-center"
            >
              <h2 class="title text-center">Learn More About Us</h2>
              <h5 class="description">
                We are the biggest Car Renting Agency that works all over the Methropolitan Area of Florence.
                We offer several kinds of cars, one for every need. We offer personalized packages based on the user's request.   
              </h5>
            </div>
          </div>
          <div class="features text-center">
            <div class="md-layout">
              
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="info">
                  <div class="icon icon-success">
                    <md-icon>verified_user</md-icon>
                  </div>
                  <h4 class="info-title">We met about our costumers</h4>
                  <p>
                    Thanks to BravohCar, carsharing has never been easier. Register, validate and drive – with BravohCar you always have a car in Florence when you need one
                  </p>
                </div>
              </div>
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="info">
                  <div class="icon icon-danger">
                    <md-icon>fingerprint</md-icon>
                  </div>
                  <h4 class="info-title">Reliable like a Fingerprint</h4>
                  <p>
                    Our service is grant to be the best in term of quality and cost. Our deal with car companies made possible to provide the best service at the best cost.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section text-center">
        <div class="container">
          <h2 class="title">Here is our team</h2>
          <div class="team">
            <div class="md-layout">
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="team-player">
                  <md-card class="md-card-plain">
                    <div class="md-layout-item md-size-50 mx-auto">
                      <img
                        :src="teamImg2"
                        alt="Thumbnail Image"
                        class="img-raised rounded-circle img-fluid"
                      />
                    </div>
                    <h4 class="card-title">
                      Leonardo Fralini
                      <br>
                      <small class="card-description text-muted">CEO</small>
                    </h4>

                    <md-card-content>
                      <p class="card-description">
                        I always wished to possess a renting car company...since i've failed my other businesses
                      </p>
                    </md-card-content>

                    <md-card-actions class="text-center">
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-twitter"></i>
                      </md-button>
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-linkedin"></i>
                      </md-button>
                    </md-card-actions>
                  </md-card>
                </div>
              </div>
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="team-player">
                  <md-card class="md-card-plain">
                    <div class="md-layout-item md-size-50 mx-auto">
                      <img
                        :src="teamImg1"
                        alt="Thumbnail Image"
                        class="img-raised rounded-circle img-fluid"
                      />
                    </div>
                    <h4 class="card-title">
                      Niccolò Sarti
                      <br>
                      <small class="card-description text-muted">Database engineer</small>
                    </h4>

                    <md-card-content>
                      <p class="card-description">The querys are my blood and the db is my heart</p>
                    </md-card-content>

                    <md-card-actions class="text-center">
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-twitter"></i>
                      </md-button>
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-instagram"></i>
                      </md-button>
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-facebook-square"></i>
                      </md-button>
                    </md-card-actions>
                  </md-card>
                </div>
              </div>
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="team-player">
                  <md-card class="md-card-plain">
                    <div class="md-layout-item md-size-50 mx-auto">
                      <img
                        :src="polo"
                        alt="Thumbnail Image"
                        class="img-raised rounded-circle img-fluid"
                      >
                    </div>
                    <h4 class="card-title">
                      Michele Polini
                      <br>
                      <small class="card-description text-muted">Finance Strategist</small>
                    </h4>

                    <md-card-content>
                      <p class="card-description">
                        The compound interest is my life !
                      </p>
                    </md-card-content>

                    <md-card-actions class="text-center">
                      <md-button href="javascript:void(0)" class="md-just-icon md-simple">
                        <i class="fab fa-twitter"></i>
                      </md-button>
                      <md-button href="javascript:void(0)" class="md-just-icon md-simple">
                        <i class="fab fa-instagram"></i>
                      </md-button>
                      <md-button href="javascript:void(0)" class="md-just-icon md-simple">
                        <i class="fab fa-facebook-square"></i>
                      </md-button>
                    </md-card-actions>
                  </md-card>
                </div>
              </div>
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="team-player">
                  <md-card class="md-card-plain">
                    <div class="md-layout-item md-size-50 mx-auto">
                      <img
                        :src="bibolaz"
                        alt="Thumbnail Image"
                        class="img-raised rounded-circle img-fluid"
                      >
                    </div>
                    <h4 class="card-title">
                      Albi Biba
                      <br>
                      <small class="card-description text-muted">Fullstack Developer</small>
                    </h4>




                    <md-card-content>
                      <p class="card-description">
                        I use API key to unlock my house door.
                      </p>
                    </md-card-content>

                    <md-card-actions class="text-center">
                      <md-button href="javascript:void(0)" class="md-just-icon md-simple">
                        <i class="fab fa-twitter"></i>
                      </md-button>
                      <md-button href="javascript:void(0)" class="md-just-icon md-simple">
                        <i class="fab fa-instagram"></i>
                      </md-button>
                      <md-button href="javascript:void(0)" class="md-just-icon md-simple">
                        <i class="fab fa-facebook-square"></i>
                      </md-button>
                    </md-card-actions>
                  </md-card>
                </div>
              </div>
              <div class="md-layout-item md-medium-size-33 md-small-size-100">
                <div class="team-player">
                  <md-card class="md-card-plain">
                    <div class="md-layout-item md-size-50 mx-auto">
                      <img
                        :src="teamImg3"
                        alt="Thumbnail Image"
                        class="img-raised rounded-circle img-fluid"
                      />
                    </div>
                    <h4 class="card-title">
                      Lorenzo Filipelli
                      <br>
                      <small class="card-description text-muted">System Engineer</small>
                    </h4>

                    <md-card-content>
                      <p class="card-description">
                        It has been 4 day since i slept well...i'm currently trying to install Arch... 
                      </p>
                    </md-card-content>

                    <md-card-actions class="text-center">
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-twitter"></i>
                      </md-button>
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-instagram"></i>
                      </md-button>
                      <md-button
                        href="javascript:void(0)"
                        class="md-just-icon md-simple"
                      >
                        <i class="fab fa-facebook-square"></i>
                      </md-button>
                    </md-card-actions>
                  </md-card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section section-contacts">
        <div class="container">
          <div class="md-layout">
            <div class="md-layout-item md-size-66 md-xsmall-size-100 mx-auto">
              <h2 class="text-center title">Sign-Up</h2>
              <h4 class="text-center description">
                  Become part of our community! <br>
                  Fill in the fields below.
              </h4>


              <!-- Filip e Polo, non modificare  -->
              <form class="contact-form" method="POST" action="http://localhost:8000/Sign-Up.php">
                <div class="md-layout">
                  
                  <div class="md-layout-item md-size-50">
                    <md-field>
                      <label>Name</label>
                      <md-input v-model="addaccount.name" type="text" name="Nome" required></md-input>
                    </md-field>
                  </div>
                  
                  <div class="md-layout-item md-size-50">
                    <md-field>
                      <label>Surname</label>
                      <md-input v-model="addaccount.surname" type="text" name="Cognome" required></md-input>
                    </md-field>
                  </div>

                  <div class="md-layout-item md-size-50">
                    <md-field>
                      <label>Card's number</label>
                      <md-input v-model="addaccount.number" type="text" name="NumeroCarta" required></md-input>
                    </md-field>
                  </div>

                  <div class="md-layout-item md-size-50">
                    <md-field>
                      <label>CVV</label>
                      <md-input v-model="addaccount.cvv" type="password" name="CVV" required></md-input>
                    </md-field>
                  </div>

                  <div class="md-layout-item md-size-50">
                    <md-field>
                      <label>Email</label>
                      <md-input v-model="addaccount.email" type="email" name="Email" required></md-input>
                    </md-field>
                  </div>
                
                <div class="md-layout-item md-size-50">
                  <md-field>
                    <label>Password</label>
                    <md-input v-model="addaccount.password" type="password" name="Psw" required></md-input>
                  </md-field>
                </div>
                
                <div class="md-layout">
                  <div class="md-layout-item md-size-33 mx-auto text-center">
                    <md-button type="submit" class="md-success">Sign-UP</md-button>
                    </div>
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  bodyClass: "landing-page",
  props: {
    header: {
      type: String,
      default: require("@/assets/img/bg7.jpg")
    },
    teamImg1: {
      type: String,
      default: require("@/assets/img/faces/avatar.jpg")
    },
    teamImg2: {
      type: String,
      default: require("@/assets/img/faces/christian.jpg")
    },
    teamImg3: {
      type: String,
      default: require("@/assets/img/faces/kendall.jpg")
    },
    polo: {
      type: String,
      default: require("@/assets/img/faces/polo.jpg")
    },
    bibolaz: {
      type: String,
      default: require("@/assets/img/faces/biba.jpg")
    }
  },
  data() {
    return {
      addaccount:{
        name: null,
        surname: null,
        email: null,
        password: null,
        cvv: null,
        number: null
      },
    };
  },
  computed: {
    headerStyle() {
      return {
        backgroundImage: `url(${this.header})`
      };
    }
  }
};
</script>

<style lang="scss" scoped>
.md-card-actions.text-center {
  display: flex;
  justify-content: center !important;
}
.contact-form {
  margin-top: 30px;
}

.md-has-textarea + .md-layout {
  margin-top: 15px;
}
</style>
