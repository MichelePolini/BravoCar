# Change Logs

## [1.1.0] 2019-01-22
### Updates
- Updated all dependencies to the latest version

## [1.0.1] 2019-01-22
### Feature
- button `Vue Material Kit Pro` from `index.vue` activated

## [1.0.0] 2018-09-27
### Initial Release
